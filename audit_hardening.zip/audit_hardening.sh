#!/bin/bash
# Security Audit and Server Hardening Script

# Define colors for output
GREEN="\e[32m"
RED="\e[31m"
YELLOW="\e[33m"
RESET="\e[0m"

# Function to audit users and groups
audit_users_groups() {
    echo -e "${GREEN}User and Group Audit:${RESET}"
    awk -F: '{ print $1 " - UID: "$3}' /etc/passwd | sort -n -k2
    echo -e "\nNon-standard UID 0 users:" 
    awk -F: '($3 == 0) {print}' /etc/passwd | grep -v "root"
    echo -e "\nUsers without passwords:" 
    awk -F: '($2 == "") {print}' /etc/shadow
}

# Function to audit file and directory permissions
audit_permissions() {
    echo -e "${GREEN}File and Directory Permissions Audit:${RESET}"
    find / -type f -perm -o+w -exec ls -l {} \;
    find / -type d -perm -o+w -exec ls -ld {} \;
    echo -e "\nChecking SUID/SGID files:" 
    find / -type f \( -perm -4000 -o -perm -2000 \) -exec ls -l {} \;
}

# Function to audit running services
service_audit() {
    echo -e "${GREEN}Service Audit:${RESET}"
    systemctl list-units --type=service --state=running
    echo -e "\nChecking sshd and iptables status:"
    systemctl is-active --quiet sshd && echo "sshd: RUNNING" || echo "sshd: STOPPED"
    systemctl is-active --quiet iptables && echo "iptables: RUNNING" || echo "iptables: STOPPED"
}

# Function to check firewall and network security
network_security_audit() {
    echo -e "${GREEN}Firewall and Network Security Audit:${RESET}"
    iptables -L
    echo -e "\nOpen Ports:" 
    netstat -tuln
    echo -e "\nIP Forwarding Status:" 
    cat /proc/sys/net/ipv4/ip_forward
}

# Function to check IP and network configurations
ip_configuration() {
    echo -e "${GREEN}IP Configuration Audit:${RESET}"
    ip addr show
    echo -e "\nPublic IPs:" 
    curl -s ifconfig.me
}

# Function to check security updates and patches
security_updates() {
    echo -e "${GREEN}Checking for Security Updates:${RESET}"
    apt-get update && apt-get upgrade --dry-run
}

# Function to perform server hardening
server_hardening() {
    echo -e "${GREEN}Applying Server Hardening:${RESET}"
    echo "Disabling root SSH login..."
    sed -i 's/PermitRootLogin yes/PermitRootLogin no/' /etc/ssh/sshd_config
    systemctl restart sshd
    echo "Setting GRUB password..."
    grub-mkpasswd-pbkdf2 | tee /boot/grub/user.cfg
    echo "Configuring iptables rules..."
    iptables -A INPUT -p tcp --dport 22 -j ACCEPT
    iptables -A INPUT -p tcp --dport 80 -j ACCEPT
    iptables -A INPUT -j DROP
    echo "Enabling automatic updates..."
    apt-get install -y unattended-upgrades
    dpkg-reconfigure -plow unattended-upgrades
}

# Function to generate summary report
generate_report() {
    echo -e "${GREEN}Generating Audit and Hardening Report:${RESET}"
    audit_users_groups > /root/audit_report.txt
    audit_permissions >> /root/audit_report.txt
    service_audit >> /root/audit_report.txt
    network_security_audit >> /root/audit_report.txt
    ip_configuration >> /root/audit_report.txt
    security_updates >> /root/audit_report.txt
    echo -e "${GREEN}Report saved to /root/audit_report.txt${RESET}"
}

# Command line arguments to trigger specific tasks
case "$1" in
    -audit)
        audit_users_groups
        audit_permissions
        service_audit
        network_security_audit
        ip_configuration
        ;;
    -harden)
        server_hardening
        ;;
    -report)
        generate_report
        ;;
    *)
        echo -e "${YELLOW}Usage: $0 {-audit|-harden|-report}${RESET}"
        ;;
esac
