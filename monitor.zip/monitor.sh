#!/bin/bash
# System Resource Monitoring Script

# Define colors for output
GREEN="\e[32m"
RED="\e[31m"
YELLOW="\e[33m"
RESET="\e[0m"

# Function to monitor CPU and Memory Usage
top_apps() {
    echo -e "${GREEN}Top 10 Applications by CPU & Memory Usage:${RESET}"
    ps aux --sort=-%cpu,-%mem | head -n 11 | awk '{print $1, $2, $3, $4, $11}'
}

# Function to monitor Network
network_monitor() {
    echo -e "${GREEN}Network Monitoring:${RESET}"
    echo "Active Connections: $(ss -s | grep estab | awk '{print $4}')"
    echo "Packet Drops: $(cat /proc/net/snmp | grep 'Tcp:' | awk '{print $14}')"
    echo "Data In/Out: $(ifconfig eth0 | grep 'RX bytes' | awk '{print $2, $6}')"
}

# Function to monitor Disk Usage
disk_usage() {
    echo -e "${GREEN}Disk Usage:${RESET}"
    df -h | awk '$5 > 80 {print $0}'
}

# Function to monitor System Load and CPU Breakdown
system_load() {
    echo -e "${GREEN}System Load:${RESET}"
    uptime
    mpstat
}

# Function to monitor Memory Usage
memory_usage() {
    echo -e "${GREEN}Memory Usage:${RESET}"
    free -m
    swapon --summary
}

# Function to monitor Active Processes
process_monitor() {
    echo -e "${GREEN}Top 5 Processes by CPU & Memory Usage:${RESET}"
    ps aux --sort=-%cpu,-%mem | head -n 6 | awk '{print $1, $2, $3, $4, $11}'
}

# Function to monitor Service Status
service_monitor() {
    echo -e "${GREEN}Service Status:${RESET}"
    for service in sshd nginx iptables; do
        systemctl is-active --quiet $service && echo "$service: RUNNING" || echo "$service: STOPPED"
    done
}

# Command line arguments to trigger specific parts
case "$1" in
    -cpu)
        top_apps
        ;;
    -network)
        network_monitor
        ;;
    -disk)
        disk_usage
        ;;
    -load)
        system_load
        ;;
    -memory)
        memory_usage
        ;;
    -process)
        process_monitor
        ;;
    -services)
        service_monitor
        ;;
    *)
        echo -e "${YELLOW}Usage: $0 {-cpu|-network|-disk|-load|-memory|-process|-services}${RESET}"
        ;;
esac
