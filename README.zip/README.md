# DevOps Technical Task

## Task 1: System Resource Monitoring

### Overview
This Bash script monitors system resources for a proxy server and provides a real-time dashboard. The script supports CLI switches to view individual sections.

### Features
- Top 10 applications consuming CPU and memory.
- Network Monitoring: Concurrent connections, packet drops, and data in/out.
- Disk Usage: Highlights partitions using more than 80% space.
- System Load: Current load and CPU breakdown.
- Memory Usage: Total, used, and swap memory.
- Process Monitoring: Active processes and top 5 by CPU/memory.
- Service Monitoring: Status of critical services like sshd, nginx, and iptables.

### Usage
```bash
chmod +x monitor.sh
./monitor.sh -cpu          # View top 10 applications
./monitor.sh -network      # View network statistics
./monitor.sh -disk         # View disk usage
./monitor.sh -load         # View system load
./monitor.sh -memory       # View memory usage
./monitor.sh -process      # View top processes
./monitor.sh -services     # View service status
```

---

## Task 2: Security Audit and Server Hardening

### Overview
This Bash script automates security audits and server hardening processes for Linux servers. It performs checks for vulnerabilities and applies hardening measures.

### Features
- User and Group Audits
- File and Directory Permissions
- Service Audits
- Firewall and Network Security Checks
- IP and Network Configuration
- Security Updates and Patching
- Log Monitoring and Custom Security Checks
- Server Hardening: SSH, GRUB, iptables, automatic updates

### Usage
```bash
chmod +x audit_hardening.sh
./audit_hardening.sh -audit       # Perform security audit
./audit_hardening.sh -harden      # Apply server hardening
./audit_hardening.sh -report      # Generate audit and hardening report
```

---

## GitHub Upload Instructions

### Step 1: Create a New Repository
- Go to [GitHub](https://github.com/).
- Click on **New** to create a new repository.
- Set a repository name, description, and mark it as public or private.

### Step 2: Initialize and Push the Project
```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin <your-repository-url>
git push -u origin main
```

### Step 3: Verify Upload
- Visit your repository to confirm that all files are uploaded successfully.

### File Structure
```
/Devops-Technical-Task
├── monitor.sh
├── audit_hardening.sh
└── README.md
```

Happy coding!